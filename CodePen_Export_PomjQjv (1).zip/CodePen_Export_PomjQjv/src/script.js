//card flip function start
function rotateCard(btn) {
  var $card = $(btn).closest(".card-container");
  console.log($card);
  if ($card.hasClass("hover")) {
    $card.removeClass("hover");
  } else {
    $card.addClass("hover");
  }
}
// card flip funtion end


//random function start
  function shuffle() {
    $(".shuffleImg").each(function() {
      var divs = $(this).find(".images");
      for (var i = 0; i < divs.length; i++) $(divs[i]).remove();

      var i = divs.length;
      if (i == 0) return false;
      while (--i) {
        var j = Math.floor(Math.random() * (i + 1));
        var tempi = divs[i];
        var tempj = divs[j];
        divs[i] = tempj;
        divs[j] = tempi;
      }
      for (var i = 0; i < divs.length; i++) {
        $(divs[i]).appendTo($("#cardbox" + (i + 1)));
      }
    });
  }



$(window).load(function() {shuffle() });
//random funtion end

function reset() {
  $(".shuffleImg").each(function() { 
    $(this).find(".hover").removeClass('hover');
  });
  window.setTimeout(function(){
    shuffle();
  }, 800);
}